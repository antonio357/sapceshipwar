import pygame
import random
import os
score_lis = []

WIDTH = 800
HEIGHT = 600

# Colors;
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (1, 1, 232)
GREEN = (55, 238, 2)

pygame.init()
pygame.mixer.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("CODING GAME...")
clock = pygame.time.Clock()


# set up assets folders
game_folder = os.path.dirname(__file__)
img_folder = os.path.join(game_folder, "images")

# Load all game grafhics
space_ship_basic_enemy = pygame.image.load(os.path.join(img_folder, "Enemy1.png")).convert()

class Enemy1(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = space_ship_basic_enemy
        self.image.set_colorkey(BLACK)
        self.rect = self.image.get_rect()
        self.rect.x = WIDTH + random.randrange(self.rect.width, self.rect.width + 1)
        self.rect.y = random.randrange(self.rect.height, HEIGHT - self.rect.height)
        self.lives = 1
        self.speedx = random.randrange(-2, -5, -1)
        self.speedy = random.randrange(-4, 2) or random.randrange(2, 5)
        self.score_value = 10

    def update(self):
        self.rect.y += self.speedy
        self.rect.x += self.speedx
        if self.rect.left < (0 - self.rect.width):
            self.kill()
        if self.lives < 0:
            self.kill()
            score_lis.append(self.score_value)
        if self.rect.top <= 0:
            self.rect.top = 0
            if self.speedy < 0:
                self.speedy = (self.speedy)*-1
            elif self.speedy == 0:
                self.speedy += 1
            elif self.speedy > 0:
                pass
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT
            if self.speedy > 0:
                self.speedy = (self.speedy)*-1
            elif self.speedy == 0:
                self.speedy -= 1
            elif self.speedy < 0:
                pass